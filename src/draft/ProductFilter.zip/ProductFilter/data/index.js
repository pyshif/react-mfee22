const data = [
  {
    id: '1',
    picture: 'http://placehold.it/32x32',
    stock: 5,
    name: 'iPhone 12 Pro',
    price: 25000,
    tags: '蘋果,大螢幕',
  },
  {
    id: '2',
    picture: 'http://placehold.it/32x32',
    stock: 5,
    name: 'iPhone 12',
    price: 15000,
    tags: '蘋果,小螢幕',
  },
  {
    id: '3',
    picture: 'http://placehold.it/32x32',
    stock: 10,
    name: 'iPhone SE',
    price: 12500,
    tags: '蘋果,小螢幕',
  },
  {
    id: '4',
    picture: 'http://placehold.it/32x32',
    stock: 10,
    name: 'iPhone XS',
    price: 22000,
    tags: '蘋果,大螢幕',
  },
  {
    id: '5',
    picture: 'http://placehold.it/32x32',
    stock: 6,
    name: 'Google Pixel 5',
    price: 17000,
    tags: '安卓,大螢幕',
  },
  {
    id: '6',
    picture: 'http://placehold.it/32x32',
    stock: 6,
    name: 'Google Pixel 4',
    price: 15500,
    tags: '安卓,大螢幕',
  },
]

export { data }
